﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TranslateScreenHandler : MonoBehaviour {

	private Canvas TranslateScreen;
	private SelectionScreenHandler selectionScreenHandler;
	private HelperFuncScript helper;
	private GameObject Remote;
	private GameObject Board;
	private Transform originalParent;
	private AssemblySpaceHandler assemblySpace;

	// Use this for initialization
	void Start () {
		TranslateScreen = this.GetComponent<Canvas> ();
		TranslateScreen.enabled = false;
		Remote = GameObject.Find ("Remote");
		Board = GameObject.Find ("Board");
		selectionScreenHandler = GameObject.Find ("ItemSelectedCanvas").GetComponent<SelectionScreenHandler> ();
		helper = GameObject.Find("Remote").GetComponent<HelperFuncScript>();
		originalParent = null;
		assemblySpace = GameObject.Find ("AssemblySpace").GetComponent<AssemblySpaceHandler> ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void showTranslateScreen()
	{
		TranslateScreen.enabled = true;
	}

	public void closeTranslateScreen()
	{
		TranslateScreen.enabled = false;
	}

	public void startTranslateMode()
	{
		//Close selection screen
		selectionScreenHandler.closeItemSelectionScreen();

		//Open this screen
		showTranslateScreen();

		//Set the current mode
		helper.setCurrentMode(helper.translateMode);

		//Change the object's color
		helper.changeObjectColor(helper.getCurrentObject(),helper.translateModeColor);

		//Set to new parent
		GameObject curObj = helper.getCurrentObject();
		originalParent = helper.getRoot (curObj);
		curObj.GetComponentInParent<Transform> ().parent = Remote.transform;

		//Freeze object rotation
		curObj.GetComponent<Rigidbody>().freezeRotation = true;

//		//Change the object's color
//		helper.changeObjectColor(helper.getCurrentObject(),helper.translateModeColor);
	}

	public void endTranslateMode()
	{
		//Close this screen
		closeTranslateScreen();

		//Set back to selection mode
		helper.setCurrentMode(helper.selectMode);

		//Revert object to original color
		helper.changeObjectColor(helper.getCurrentObject(),helper.getOriginalColor(helper.getCurrentObject()));

		//Revert to old parent - depends on parent
		GameObject curObj = helper.getCurrentObject();
//		curObj.GetComponentInParent<Transform> ().parent = Board.transform;

//		Transform root = helper.getRoot (curObj);
		curObj.GetComponentInParent<Transform> ().parent = originalParent;

		//Allow object rotation
		curObj.GetComponent<Rigidbody>().freezeRotation = false;

		if (helper.getCurWorkSpace () == helper.assemblySpace) {
			assemblySpace.updateFirstObject ();
		}

		//Set current object to null
		helper.setCurrentObject(null);
	}

}
