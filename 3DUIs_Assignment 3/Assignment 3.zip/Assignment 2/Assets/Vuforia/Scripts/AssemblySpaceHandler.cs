﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AssemblySpaceHandler : MonoBehaviour {

	private HelperFuncScript helper;
	private GameObject Remote;
	private GameObject assemblySpace;
	private string curText;
	private SelectionScreenHandler selectionScreenHandler;
	private GameObject Board;

	private Canvas commitCanvas;
	private Canvas clearCanvas;

	// Use this for initialization
	void Start () {
		Remote = GameObject.Find ("Remote");
		helper = GameObject.Find("Remote").GetComponent<HelperFuncScript>();
		assemblySpace = GameObject.Find ("AssemblySpace");
		curText = "";
		selectionScreenHandler = GameObject.Find ("ItemSelectedCanvas").GetComponent<SelectionScreenHandler> ();

		commitCanvas = GameObject.Find ("ConfirmCommitCanvas").GetComponent<Canvas>();
		clearCanvas = GameObject.Find ("ConfirmClearCanvas").GetComponent<Canvas> ();

		commitCanvas.enabled = false;
		clearCanvas.enabled = false;

		Board = GameObject.Find ("Board");
	}
	
	// Update is called once per frame
	void Update () {

	}

	//Update first object in workspace from objects in assembly space 
	public void updateFirstObject()
	{
		GameObject first = helper.getFirstInAssemblySpace ();
//		GameObject firstClone = Instantiate (first);
		GameObject firstCopy = helper.getFirstCopy ();

		//Update the "first"
		if (assemblySpace.transform.hasChanged==true && helper.getCurWorkSpace () == helper.assemblySpace &&
			firstCopy != null) {

			first.SetActive(false);
//			
			float assemblyScale = 9.3f;
			GameObject newFirst;
			newFirst = Instantiate(assemblySpace,firstCopy.transform.position,assemblySpace.transform.rotation,Board.transform);

			newFirst.transform.localScale = (1.0f/assemblyScale) * assemblySpace.transform.localScale;
//			first.transform.localScale = assemblyScale * first.transform.localScale;
			helper.updateFirstInAssemblySpace (newFirst);


//			first.GetComponent<Renderer>().enabled = true;
//			first.SetActive(true);
		}
//			newFirst.SetActive (true);
//			//Set first to new first 
//			first = newFirst;
//		}
	}

	public bool containsObject(GameObject obj)
	{
		foreach (Transform child in assemblySpace.transform)
		{
			if (child.tag == obj.tag) {
				return true;
			}
		}

		return false;
	}

	public void sendToAssemblySpace()
	{
		GameObject curObj = helper.getCurrentObject ();
		bool containsObj = containsObject (curObj);
		string label;

		//Send if none of that object in assembly space
		if (containsObj == false) {

			if (checkEmpty () == true) {
				helper.setFirstInAssemblySpace (curObj);
				//Also get initial specs
			}

			Vector3 centerOfMass = assemblySpace.transform.position;

//			GameObject clone = Instantiate (curObj, centerOfMass, Quaternion.identity,assemblySpace.transform);
			GameObject clone;

			if (curObj.tag.Contains ("group")) {
				clone = Instantiate (curObj, centerOfMass, Quaternion.identity, assemblySpace.transform) as GameObject;
			}

			else {
					
				clone = Instantiate(Resources.Load(curObj.name),centerOfMass, Quaternion.identity,assemblySpace.transform) as GameObject;
			}

			//		
			float adjustedSize = helper.getObjectAdjustedSize (curObj);
			clone.transform.localScale = curObj.transform.localScale;
			//Set clone's color and tag 
			helper.changeObjectColor(curObj,helper.getOriginalColor(curObj));
			helper.changeObjectColor(clone,helper.getOriginalColor(curObj));
			clone.tag = curObj.tag;
			clone.name = curObj.name;
			curText = "Sending object to the assembly space...";
			helper.setCurWorkSpace (helper.assemblySpace);
			selectionScreenHandler.closeItemSelectionScreen ();
		}

		//Otherwise don't send 
		else {
			curText = "This object is already there!";
		}

//		Debug.Log (curText);
		//Show message either way 
//		OnGUI();
	}

	public bool checkEmpty()
	{
		foreach (Transform child in assemblySpace.transform) {
			if (child.tag.Contains ("animal")) {
				return false;
			}
		}

		return true;
	}

	private void OnGUI()
	{
		GUI.Label (new Rect (0, 0, 100, 20), curText);
	}

	//Called when 'Yes' clicked for clear;
	public void clearBoard()
	{
		//Deletes all elements from AssemblySpace
		foreach (Transform child in assemblySpace.transform) {
			if (child.tag.Contains("animal")) {
				Destroy(child.gameObject);
			}
		}

		//Resets 'First' object in assembly space - perhaps make clone 
		GameObject first = helper.getFirstInAssemblySpace();
		first.SetActive (false);
		GameObject firstCopy = helper.getFirstCopy ();
		first = firstCopy; // make sure same size,orientation,position 
		first.transform.position = firstCopy.transform.position;
		first.transform.rotation = firstCopy.transform.rotation;
		first.transform.localScale = firstCopy.transform.localScale;
		first.SetActive (true);
		helper.setFirstInAssemblySpace (null);

		//Set current space to workspace
		helper.setCurWorkSpace(helper.workSpace);

		//Close selection screen
		selectionScreenHandler.closeItemSelectionScreen ();

		endClearMode ();
	}

	//Called when 'Yes' clicked for commit 
	public void commitBoard()
	{
		//Updates group object's tag 
		GameObject first = helper.getFirstInAssemblySpace ();
		first.tag = "animal_group";

		helper.setFirstInAssemblySpace(null);

		//Deletes all elements from assembly space
		foreach (Transform child in assemblySpace.transform) {
			if (child.tag.Contains("animal")) {
				Destroy(child.gameObject);
			}
		}

		//Set current space to workspace
		helper.setCurWorkSpace(helper.workSpace);

		//Close selection screen
		selectionScreenHandler.closeItemSelectionScreen ();

		endCommitMode ();
	}

	//Commit Button clicked  
	public void startCommitMode()
	{
		//Close selection screen
		selectionScreenHandler.closeItemSelectionScreen();

		//Open this screen
		showCommitScreen();

		//Set the current mode
		helper.setCurrentMode(helper.commitMode);

		//Change the object's color
		helper.changeObjectColor(helper.getCurrentObject(),helper.commitModeColor);
	}

	//Commit - No Button clicked
	public void endCommitMode()
	{
		//Close this screen
		hideCommitScreen();

		//Set back to selection mode
		helper.setCurrentMode(helper.selectMode);

		//Revert object to original color
		helper.changeObjectColor(helper.getCurrentObject(),helper.getOriginalColor(helper.getCurrentObject()));

		//Set current object to null
		helper.setCurrentObject(null);
	}

	//Clear Button clicked 
	public void startClearMode()
	{
		//Close selection screen
		selectionScreenHandler.closeItemSelectionScreen();

		//Open this screen
		showClearScreen();

		//Set the current mode
		helper.setCurrentMode(helper.clearMode);

		//Change the object's color
		helper.changeObjectColor(helper.getCurrentObject(),helper.clearModeColor);
	}

	//Clear - No Button clicked 
	public void endClearMode()
	{
		//Close this screen
		hideClearScreen();

		//Set back to selection mode
		helper.setCurrentMode(helper.selectMode);

		//Revert object to original color
		helper.changeObjectColor(helper.getCurrentObject(),helper.getOriginalColor(helper.getCurrentObject()));

		//Set current object to null
		helper.setCurrentObject(null);
	}

	private void showClearScreen()
	{
		clearCanvas.enabled = true;
	}

	private void hideClearScreen()
	{
		clearCanvas.enabled = false;
	}

	private void showCommitScreen()
	{
		commitCanvas.enabled = true;
	}

	private void hideCommitScreen()
	{
		commitCanvas.enabled = false;
	}
}
