﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScaleScreenHandler : MonoBehaviour {

	private Canvas ScaleScreen;
	private SelectionScreenHandler selectionScreenHandler;
	private HelperFuncScript helper;
	private GameObject Remote;
	private GameObject Board;
	private AssemblySpaceHandler assemblySpace;

	// Use this for initialization
	void Start () {
		ScaleScreen = this.GetComponent<Canvas> ();
		ScaleScreen.enabled = false;
		Remote = GameObject.Find ("Remote");
		Board = GameObject.Find ("Board");
		selectionScreenHandler = GameObject.Find ("ItemSelectedCanvas").GetComponent<SelectionScreenHandler> ();
		helper = GameObject.Find("Remote").GetComponent<HelperFuncScript>();
		assemblySpace = GameObject.Find ("AssemblySpace").GetComponent<AssemblySpaceHandler> ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void showScaleScreen()
	{
		ScaleScreen.enabled = true;
	}

	public void closeScaleScreen()
	{
		ScaleScreen.enabled = false;
	}

	public void startScaleMode()
	{
		//Close selection screen
		selectionScreenHandler.closeItemSelectionScreen();

		//Open this screen
		showScaleScreen();

		//Set the current mode
		helper.setCurrentMode(helper.scaleMode);
			
		//Change the object's color
		helper.changeObjectColor(helper.getCurrentObject(),helper.scaleModeColor);

	}

	public void endScaleMode()
	{
		//Close this screen
		closeScaleScreen();

		//Set back to selection mode
		helper.setCurrentMode(helper.selectMode);

		//Revert object to original color
		helper.changeObjectColor(helper.getCurrentObject(),helper.getOriginalColor(helper.getCurrentObject()));

		if (helper.getCurWorkSpace () == helper.assemblySpace) {
			assemblySpace.updateFirstObject ();
		}

		//Set current object to null
		helper.setCurrentObject(null);

	}

}
