﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateScreenHandler : MonoBehaviour {

	private Canvas RotateScreen;
	private SelectionScreenHandler selectionScreenHandler;
	private HelperFuncScript helper;
	private GameObject Remote;
	private GameObject Board;
	private AssemblySpaceHandler assemblySpace;

	// Use this for initialization
	void Start () {
		RotateScreen = this.GetComponent<Canvas> ();
		RotateScreen.enabled = false;
		Remote = GameObject.Find ("Remote");
		Board = GameObject.Find ("Board");
		selectionScreenHandler = GameObject.Find ("ItemSelectedCanvas").GetComponent<SelectionScreenHandler> ();
		helper = GameObject.Find("Remote").GetComponent<HelperFuncScript>();
		assemblySpace = GameObject.Find ("AssemblySpace").GetComponent<AssemblySpaceHandler> ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void showRotateScreen()
	{
		RotateScreen.enabled = true;
	}

	public void closeRotateScreen()
	{
		RotateScreen.enabled = false;
	}

	public void startRotateMode()
	{
		//Close selection screen
		selectionScreenHandler.closeItemSelectionScreen();

		//Open this screen
		showRotateScreen();

		//Add Collider if object is group
		GameObject curObj = helper.getCurrentObject();

		if (curObj.tag.Contains ("group")) {
			SphereCollider newCollider = curObj.AddComponent<SphereCollider> ();
			newCollider.center = curObj.transform.position;
			newCollider.radius = 5.0f;
		}

		//Set the current mode
		helper.setCurrentMode(helper.rotateMode);

		//Change the object's color
		helper.changeObjectColor(helper.getCurrentObject(),helper.rotateModeColor);
	}

	public void endRotateMode()
	{
		//Close this screen
		closeRotateScreen();

		//Set back to selection mode
		helper.setCurrentMode(helper.selectMode);

		//Remove Collider if object is group 
		GameObject curObj = helper.getCurrentObject();

		if (curObj.tag.Contains ("group")) {
			SphereCollider collider = curObj.GetComponent<SphereCollider> ();
			Destroy (collider);
		}

		//Revert object to original color
		helper.changeObjectColor(helper.getCurrentObject(),helper.getOriginalColor(helper.getCurrentObject()));

		if (helper.getCurWorkSpace () == helper.assemblySpace) {
			assemblySpace.updateFirstObject ();
		}

		//Set current object to null
		helper.setCurrentObject(null);
	}
}
