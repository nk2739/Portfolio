﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreateScreenHandler : MonoBehaviour {

	private Canvas createScreen;
	private SelectionScreenHandler selectionScreenHandler;
	private HelperFuncScript helper;
	private GameObject Remote;
	private GameObject Board;
	private GameObject assemblySpace;
	private AssemblySpaceHandler assemblySpaceHandler;

	// Use this for initialization
	void Start () {
		createScreen = this.GetComponent<Canvas> ();
		createScreen.enabled = false;
		Remote = GameObject.Find ("Remote");
		Board = GameObject.Find ("Board");
		assemblySpace = GameObject.Find ("AssemblySpace");
		selectionScreenHandler = GameObject.Find ("ItemSelectedCanvas").GetComponent<SelectionScreenHandler> ();
		helper = GameObject.Find("Remote").GetComponent<HelperFuncScript>();
		assemblySpaceHandler = GameObject.Find ("AssemblySpace").GetComponent<AssemblySpaceHandler> ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void showCreateScreen()
	{
		createScreen.enabled = true;
	}

	public void closeCreateScreen()
	{
		createScreen.enabled = false;
	}

	public void startCreateMode()
	{
		//Close selection screen
		selectionScreenHandler.closeItemSelectionScreen();

		//Open this screen
		showCreateScreen();

		//Set the current mode
		helper.setCurrentMode(helper.createMode);

		//Change the object's color
		helper.changeObjectColor(helper.getCurrentObject(),helper.createModeColor);
	}

	public void endCreateMode()
	{
		//Close this screen
		closeCreateScreen();

		//Set back to selection mode
		helper.setCurrentMode(helper.selectMode);

		//Revert object to original color
		helper.changeObjectColor(helper.getCurrentObject(),helper.getOriginalColor(helper.getCurrentObject()));

		//Set current object to null
		helper.setCurrentObject(null);
	}

	public void cloneObject()
	{

		//Depends on current workspace
		string curWorkSpace = helper.getCurWorkSpace();
		Transform root;
		Vector3 centerOfMass;

		if (curWorkSpace == helper.workSpace) {
			root = Board.transform;
			centerOfMass = Board.transform.position;
		} else {
			root = assemblySpace.transform;
			centerOfMass = assemblySpace.transform.position;
		}

//		Transform root = helper.getRoot (helper.getCurrentObject ());
//
//		Vector3 centerOfMass;
//
//		if (root.name == "Board") {
//			centerOfMass = Board.transform.position;
//
//		} else {
//			centerOfMass = assemblySpace.transform.position;
//		}

		//Create copy here
		Vector3 curPosition = helper.getCurrentObject().transform.position;
//		Vector3 centerOfMass = Board.transform.position;
//		Vector3 newPosition = new Vector3 (0, 0, curPosition.z);
		Vector3 newPosition = centerOfMass;

		GameObject curObj = helper.getCurrentObject ();

		//Change parent later
//		GameObject clone = Instantiate(Resources.Load(curObj.name),newPosition, Quaternion.identity,Board.transform) as GameObject;
		GameObject clone = Instantiate(Resources.Load(curObj.name),newPosition, Quaternion.identity,root) as GameObject;

//		GameObject clone = Instantiate (curObj, newPosition, Quaternion.identity,Board.transform);
		float adjustedSize = helper.getObjectAdjustedSize (curObj);
//		clone.transform.localScale = new Vector3 (curObj.transform.localScale.x, curObj.transform.localScale.y, curObj.transform.localScale.z);
//		clone.transform.localScale = adjustedSize * curObj.GetComponent<Renderer>().bounds.size;
		clone.transform.localScale = adjustedSize * curObj.transform.localScale;
		//Set clone's color and tag 
		helper.changeObjectColor(clone,helper.getOriginalColor(curObj));
		clone.tag = curObj.tag;
		clone.name = curObj.name;
		endCreateMode ();

		if (helper.getCurWorkSpace () == helper.assemblySpace) {
			assemblySpaceHandler.updateFirstObject ();
		}
	}
}
