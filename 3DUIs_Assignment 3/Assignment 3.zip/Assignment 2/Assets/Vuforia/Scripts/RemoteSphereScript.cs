﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RemoteSphereScript : MonoBehaviour {

	private HelperFuncScript helper;
	private SelectionScreenHandler selectionScreenHandler;
	private float rotationSpeed;
	private GameObject RemoteSphere;
	private CreateScreenHandler createScreen;
	private AssemblySpaceHandler assemblySpace;

	// Use this for initialization
	void Start () {
		helper = GameObject.Find("Remote").GetComponent<HelperFuncScript>();
		selectionScreenHandler = GameObject.Find ("ItemSelectedCanvas").GetComponent<SelectionScreenHandler> ();
		rotationSpeed = 5f;
		RemoteSphere = GameObject.Find ("RemoteSphere");
		createScreen = GameObject.Find ("ConfirmCreateCanvas").GetComponent<CreateScreenHandler> ();
		assemblySpace = GameObject.Find ("AssemblySpace").GetComponent<AssemblySpaceHandler> ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	 void OnCollisionEnter(Collision collision)
	{
//		Debug.Log ("Collision occured");

		string curMode = helper.getCurrentMode ();

		if (collision.collider.tag.Contains("animal"))
		{
			GameObject prevObj = helper.getCurrentObject ();
			GameObject curObj = collision.collider.transform.gameObject;

//			print (curObj.name);

			if (curMode == helper.selectMode) {

				//If same deselect and close menu - curr, none - revert to OG color
				if (curObj == prevObj) {
					helper.setCurrentObject (null);
					helper.changeObjectColor (curObj, helper.getOriginalColor (curObj));
					selectionScreenHandler.closeItemSelectionScreen ();
				}

				//If null select and open menu - curr, this - new color
				if (prevObj == null) {
					helper.setCurrentObject (curObj);
					selectionScreenHandler.showItemSelectionScreen ();
				}

				//If diff select and keep menu - curr,new - new color and revert old 
				if (curObj != prevObj && prevObj != null) {
					helper.setCurrentObject (curObj);
					helper.changeObjectColor (prevObj, helper.getOriginalColor (prevObj));
				}
			}
				
		}
	}

	void OnCollisionStay(Collision collision)
	{
		Debug.Log ("Collision continuing");
	}

	void OnCollisionExit(Collision collision)
	{
		Debug.Log ("Collision done");
	}

	void OnTriggerEnter(Collider other)
	{
//		Debug.Log ("Trigger occured");

		string curMode = helper.getCurrentMode ();

		if (other.tag.Contains("animal"))
		{
			GameObject prevObj = helper.getCurrentObject ();
			GameObject curObj = other.transform.gameObject;

			GameObject parent = null;

//			if (curObj.transform.parent.transform.parent != null) {
//				grandParent = curObj.transform.parent.transform.parent.gameObject; 
//			}

			if (curObj.transform.parent != null) {
				parent = curObj.transform.parent.gameObject; 
			}

//			if (curObj.transform.parent.transform.parent.gameObject != null) {
//				grandParent = curObj.transform.parent.transform.parent.gameObject; 
//			}

//			Debug.Log ("GrandParent:" + grandParent.tag);

//			if(grandParent != null && grandParent.tag.Contains("group")){
//				curObj = grandParent;
//				Debug.Log ("Group chosen");
//			}

			if(parent != null && parent.tag.Contains("group") && helper.getCurWorkSpace() != helper.assemblySpace){
				curObj = parent;
				Debug.Log ("Group chosen");
			}

//			print (curObj.name);

			if (curMode == helper.selectMode)
			{
				string workSpace = helper.getCurWorkSpace ();
				Transform root = helper.getRoot (curObj);

				if ((workSpace == helper.assemblySpace && root.name != "Board") || workSpace == helper.workSpace) {
					//If same deselect and close menu - curr, none - revert to OG color
					if (curObj == prevObj) {
						selectionScreenHandler.updateSelectionScreen ();
						selectionScreenHandler.closeItemSelectionScreen ();
						helper.setCurrentObject (null);
						helper.changeObjectColor (curObj, helper.getOriginalColor (curObj));
					}

					//If null select and open menu - curr, this - new color
					if (prevObj == null) {
						helper.setCurrentObject (curObj);
						selectionScreenHandler.updateSelectionScreen ();
						selectionScreenHandler.showItemSelectionScreen ();
					}

					//If diff select and keep menu - curr,new - new color and revert old 
					if (curObj != prevObj && prevObj != null) {
						helper.setCurrentObject (curObj);
						helper.changeObjectColor (prevObj, helper.getOriginalColor (prevObj));
						selectionScreenHandler.updateSelectionScreen ();
						selectionScreenHandler.showItemSelectionScreen ();
					}
				}

//				assemblySpace.sendToAssemblySpace ();
			}

			if (curMode == helper.scaleMode)
			{
				if (curObj == prevObj)
				{
					Vector3 point = RemoteSphere.transform.position;
					scaleObject (curObj, point);
				}
			}

//			if (curMode == helper.createMode) 
//			{
//				if (curObj == prevObj) {
//					Debug.Log ("Create Called");
//					createScreen.cloneObject ();
//				}
//			}
		}
	}

	void OnTriggerStay(Collider other)
	{
//		Debug.Log ("Trigger stayed");

		string curMode = helper.getCurrentMode ();

		if (other.tag.Contains ("animal"))
		{
			GameObject prevObj = helper.getCurrentObject ();
			GameObject curObj = other.transform.gameObject;

			if (curMode == helper.rotateMode) 
			{
				if (curObj == prevObj) 
				{
//					Debug.Log ("Object should rotate");
					if (curObj.tag.Contains ("group")) {
						curObj = helper.getCurrentObject ();
					}

					Vector3 moveTowards = RemoteSphere.transform.position;
					rotateObject (curObj, moveTowards);
				}
			}
		}
	}

	void OnTriggerExit(Collider other)
	{
		Debug.Log ("Trigger exited");
	}

	private void rotateObject(GameObject curObj, Vector3 moveTowards)
	{
		Transform target = curObj.transform;

		Vector3 direction = (target.position - moveTowards).normalized;

		Quaternion lookAtDirection = Quaternion.LookRotation (direction);

		target.rotation = Quaternion.Slerp (target.rotation, lookAtDirection, Time.deltaTime * rotationSpeed);
	}

	private void scaleObject(GameObject curObj, Vector3 point)
	{
		Vector3 curPosition = curObj.transform.position;
		float newSize;

		if (curPosition.x <= point.x) {
			newSize = 1.5f;

		} else {
			newSize = 0.66f;
		}

		curObj.transform.localScale = new Vector3 (curObj.transform.localScale.x * newSize, curObj.transform.localScale.y * newSize, curObj.transform.localScale.z * newSize);
	}
}
