﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SelectionScreenHandler : MonoBehaviour {

	private Canvas ItemSelectedScreen;
	private HelperFuncScript helper;
	private GameObject rotateModeButton;
	private GameObject scaleModeButton;
	private GameObject translateModeButton;
	private GameObject createModeButton;
	private GameObject deleteModeButton;
	private GameObject sendToAssemblyButton;
	private GameObject commitButton;
	private GameObject clearButton;

	//Instantiate buttons 

	// Use this for initialization
	void Start () {
		ItemSelectedScreen = this.GetComponent<Canvas> ();
		helper = GameObject.Find("Remote").GetComponent<HelperFuncScript>();
		rotateModeButton = GameObject.Find ("RotateModeButton");
		scaleModeButton = GameObject.Find ("ScaleModeButton");
		translateModeButton = GameObject.Find ("TranslateModeButton");
		createModeButton = GameObject.Find ("CreateButton");
		deleteModeButton = GameObject.Find ("DeleteButton");
		sendToAssemblyButton = GameObject.Find ("AssemblyButton");
		commitButton = GameObject.Find ("CommitButton");
		clearButton = GameObject.Find ("ClearButton");
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void showItemSelectionScreen()
	{
		ItemSelectedScreen.enabled = true;
	}

	public void closeItemSelectionScreen()
	{
		ItemSelectedScreen.enabled = false;
	}

	public void updateSelectionScreen()
	{
		GameObject obj = helper.getCurrentObject();
		Transform root = helper.getRoot (obj);
		//Set all inactive initially
		rotateModeButton.SetActive(false);
		scaleModeButton.SetActive (false);
		translateModeButton.SetActive (false);
		createModeButton.SetActive (false);
		deleteModeButton.SetActive (false);
		sendToAssemblyButton.SetActive (false);
		commitButton.SetActive (false);
		clearButton.SetActive (false);


		//Original Targets - only create button
		if (root.name == "OriginalImages") {
			createModeButton.SetActive (true);
		}

		//In workspace - delete, translate, rotate, scale, send
		if (root.name == "Board") {
			deleteModeButton.SetActive (true);
			translateModeButton.SetActive (true);
			rotateModeButton.SetActive (true);
			scaleModeButton.SetActive (true);
			sendToAssemblyButton.SetActive (true);
		}

		//In assembly space - delete, translate, rotate, scale, commit, clear 
		if (root.name == "AssemblySpace") {
			deleteModeButton.SetActive (true);
			translateModeButton.SetActive (true);
			rotateModeButton.SetActive (true);
			scaleModeButton.SetActive (true);
			commitButton.SetActive (true);
			clearButton.SetActive (true);
//			helper.setCurWorkSpace (helper.assemblySpace);
		}
	}
}
