﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HelperFuncScript : MonoBehaviour {

	private GameObject RemoteSphere;
	private LineRenderer laser;
	public GameObject curObject;
	private string curMode;

	private GameObject elephant;
	private GameObject horse;
	private GameObject lion;
	private GameObject wolf;

	private Renderer elephantRenderer;
	private Renderer horseRenderer;
	private Renderer lionRenderer;
	private Renderer wolfRenderer;

	public string selectMode = "selectMode";
	public string scaleMode = "scaleMode";
	public string rotateMode = "rotateMode";
	public string translateMode = "translateMode";
	public string createMode = "createMode";
	public string deleteMode = "deleteMode";
	public string commitMode = "commitMode";
	public string clearMode = "clearMode";

	public Color selectModeColor = Color.yellow;
	public Color scaleModeColor = Color.magenta;
	public Color rotateModeColor = Color.black;
	public Color translateModeColor = Color.blue;
	public Color deleteModeColor = Color.red;
	public Color createModeColor = Color.green;
	public Color commitModeColor = Color.grey;
	public Color clearModeColor = Color.cyan;

	public List<Color> colorList = new List<Color>();

	private Material elephantMat;
	private Material horseMat;
	private Material lionMat;
	private Material wolfMat;

	private float elephantSize = 0.035f;
	private float horseSize = 0.001f;
	private float lionSize = 0.04f;
	private float wolfSize = 0.08f;

	private string curWorkSpace;

	public string assemblySpace = "AssemblySpace";
	public string workSpace = "WorkSpace";

	private GameObject firstInAssemblySpace;
	private GameObject firstCopy;

	private Text workSpaceText;

//	Canvas ItemSelectedScreen;

	public void changeWandColors(string newMode)
	{
		Color newColor;

		if (newMode == selectMode) {
			newColor = selectModeColor;
		} else if (newMode == scaleMode) {
			newColor = scaleModeColor;
		} else if (newMode == rotateMode) {
			newColor = rotateModeColor;
		} else if (newMode == translateMode) {
			newColor = translateModeColor;
		} else if (newMode == createMode) {
			newColor = createModeColor;
		} else if (newMode == deleteMode) {
			newColor = deleteModeColor;
		} else if (newMode == commitMode) {
			newColor = commitModeColor;
		} else if (newMode == clearMode) {
			newColor = clearModeColor;
		}
		else {
			newColor = Color.white;
		}
		RemoteSphere = GameObject.Find ("RemoteSphere");
		RemoteSphere.GetComponent<Renderer>().material.color = newColor;
//		laser = RemoteSphere.GetComponent<LineRenderer> ();
//		laser.material.color = newColor;
	}

	public Color getOriginalColor(GameObject obj)
	{
		if (obj.tag.Contains ("lion")) {
			return lionMat.color;
		} else if (obj.tag.Contains ("wolf")) {
			return wolfMat.color;
		} else if (obj.tag.Contains ("horse")) {
			return horseMat.color;
		} else if (obj.tag.Contains ("elephant")) {
			return elephantMat.color;
		}
		else {
			return Color.white;
		}
	}



	public void changeObjectColor(GameObject obj, Color newColor) 
	{
		if (obj.tag.Contains("group")) {

			if (colorList.Contains(newColor)) {
				foreach (Transform child in obj.transform) {
//					GameObject grandChildObj = child.GetChild (0).gameObject;
//					grandChildObj.GetComponent<Renderer> ().material.color = newColor;
					child.gameObject.GetComponent<Renderer>().material.color = newColor;
				}
			}

			else {
				foreach (Transform child in obj.transform) {
//					GameObject grandChildObj = child.GetChild (0).gameObject;
//					grandChildObj.GetComponent<Renderer> ().material.color = getOriginalColor(grandChildObj);
					child.gameObject.GetComponent<Renderer>().material.color = getOriginalColor(child.gameObject);
				}
			}
		}
			
		else {
			obj.GetComponent<Renderer> ().material.color = newColor;
		}
	}

	public void setCurWorkSpace(string space)
	{
		workSpaceText = GameObject.Find ("WorkSpaceText").GetComponent<Text> ();
		curWorkSpace = space;
		updateWorkSpaceText (curWorkSpace);
	}
		
	public string getCurWorkSpace()
	{
		return curWorkSpace;
	}

	public void updateWorkSpaceText(string space)
	{
		if (space == workSpace) {
			workSpaceText.text = "Work Space";
		}

		if (space == assemblySpace) {
			workSpaceText.text = "Assembly Space";
		}
	}

	public float getObjectAdjustedSize(GameObject obj)
	{
		if (obj.tag.Contains ("lion")) {
			return lionSize;
		}

		else if (obj.tag.Contains ("wolf")) {
			return wolfSize;
		}

		else if (obj.tag.Contains ("horse")) {
			return horseSize;
		}

		else if (obj.tag.Contains ("elephant")) {
			return elephantSize;
		} else {
			return 0.01f;
		}
	}

	public void setCurrentObject(GameObject newObj)
	{
		curObject = newObj;

		if (newObj != null) {
			changeObjectColor (curObject, selectModeColor);
		}
	}

	public GameObject getCurrentObject()
	{
		return curObject;
	}

	public void setCurrentMode(string newMode)
	{
		curMode = newMode;
		changeWandColors (curMode);
	}

	public string getCurrentMode()
	{
		return curMode;
	}

	public Transform getRoot(GameObject obj)
	{
		return obj.transform.root;
	}

	public void setFirstInAssemblySpace(GameObject obj)
	{
		firstInAssemblySpace = obj;
		firstCopy = obj;
	}

	public GameObject getFirstInAssemblySpace()
	{
		return firstInAssemblySpace;
	}

	public void updateFirstInAssemblySpace(GameObject newObj)
	{
		firstInAssemblySpace = newObj;
	}

	public GameObject getFirstCopy()
	{
		return firstCopy;
	}

//	public void showItemSelectedScreen()
//	{
//		ItemSelectedScreen.ac
//	}
//
//	public void closeItemSelectedScreen()
//	{
//
//	}

	// Use this for initialization
	void Start () {
		RemoteSphere = GameObject.Find ("RemoteSphere");
//		laser = RemoteSphere.GetComponent<LineRenderer> ();

		elephant = GameObject.Find ("Elephant");
		horse = GameObject.Find ("Horse");
		lion = GameObject.Find ("Lion");
		wolf = GameObject.Find ("Wolf");

		elephantRenderer = elephant.GetComponent<Transform> ().GetChild(0).GetComponent<Renderer> ();
		horseRenderer = horse.GetComponent<Transform> ().GetChild(0).GetComponent<Renderer> ();
		lionRenderer = lion.GetComponent<Transform> ().GetChild(0).GetComponent<Renderer> ();
		wolfRenderer = wolf.GetComponent<Transform> ().GetChild(0).GetComponent<Renderer> ();
			
//		renderer = lighthouse.GetComponent<Renderer> ();

		elephantMat = Instantiate (elephantRenderer.material);
		horseMat = Instantiate (horseRenderer.material);
		lionMat = Instantiate (lionRenderer.material);
		wolfMat = Instantiate (wolfRenderer.material);

		elephantRenderer.material = elephantMat;
		horseRenderer.material = horseMat;
		lionRenderer.material = lionMat;
		wolfRenderer.material = wolfMat;

//		selectModeColor = Color.yellow;
//		public Color scaleModeColor = Color.magenta;
//		public Color rotateModeColor = Color.black;
//		public Color translateModeColor = Color.blue;
//		public Color deleteModeColor = Color.red;
//		public Color createModeColor = Color.green;
//		public Color commitModeColor = Color.grey;
//		public Color clearModeColor = Color.cyan;

		colorList.Add (selectModeColor);
		colorList.Add (scaleModeColor);
		colorList.Add (rotateModeColor);
		colorList.Add (translateModeColor);
		colorList.Add (deleteModeColor);
		colorList.Add (createModeColor);
		colorList.Add (commitModeColor);
		colorList.Add (clearModeColor);

//		workSpaceText = GameObject.Find ("WorkSpaceText").GetComponent<Text> ();
//		ItemSelectedScreen = GameObject.Find ("ItemSelectedCanvas").GetComponent<Canvas>();

//		matInstance = Instantiate (renderer.material);
//		renderer.material = matInstance;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
