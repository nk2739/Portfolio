﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Vuforia;

public class RemoteHandler : MonoBehaviour, ITrackableEventHandler {

	private TrackableBehaviour mTrackableBehavior;
	private bool isRendered = false;
	private GameObject RemoteSphere;
	private float rayLength;
	private LineRenderer laser;
	private float laserWidth = 1f;
	private float laserLength = 100f;
	private GameObject capsule;
//	public bool itemSelected;
//
//	public bool selectMode;
//	public bool translateMode;
//	public bool rotateMode;
//	public bool scaleMode;
//	Behaviour birdBehaviour = GameObject.Find ("bird").GetComponent<BirdScript> ();
	private HelperFuncScript helper;
	private SelectionScreenHandler selectionScreenHandler;
	private TranslateScreenHandler translateScreenHander;
	private ScaleScreenHandler scaleScreenHandler;
	private RotateScreenHandler rotateScreenHandler;

	// Use this for initialization
	void Start () {
		RemoteSphere = GameObject.Find ("RemoteSphere");
//		capsule = GameObject.Find ("Capsule");
		rayLength = 100.0f;

		Screen.orientation = ScreenOrientation.LandscapeLeft;

		mTrackableBehavior = GetComponent<TrackableBehaviour> ();

		if (mTrackableBehavior) 
		{
			mTrackableBehavior.RegisterTrackableEventHandler (this);

		}
//		laser = RemoteSphere.GetComponent<LineRenderer> ();
//		Vector3[] initLaserPositions = new Vector3[2] { Vector3.zero, Vector3.zero };
//
//		laser.SetPositions (initLaserPositions);
//		laser.SetWidth (laserWidth, laserWidth);
////		laser.startColor = Color.red;
//		laser.endColor = Color.red;
//		laser.SetColors (Color.red, Color.red);
//		laser.GetComponent<Material> ().color = Color.red;
		helper = GameObject.Find("Remote").GetComponent<HelperFuncScript>();
		helper.setCurrentMode (helper.selectMode);
		helper.setCurrentObject (null);
		helper.setCurWorkSpace (helper.workSpace);
//		helper.setCurrentObject (GameObject.Find ("elephant"));
//		helper.setCurrentMode(helper.createMode);

		//Close all screens initially
		selectionScreenHandler = GameObject.Find ("ItemSelectedCanvas").GetComponent<SelectionScreenHandler> ();
		selectionScreenHandler.closeItemSelectionScreen ();

//		translateScreenHander = GameObject.Find ("TranslateModeCanvas").GetComponent<TranslateScreenHandler> ();
//		translateScreenHander.closeTranslateScreen ();
//
//		scaleScreenHandler = GameObject.Find ("ScaleModeCanvas").GetComponent<ScaleScreenHandler> ();
//		scaleScreenHandler.closeScaleScreen ();
//
//		rotateScreenHandler = GameObject.Find ("RotateModeCanvas").GetComponent<RotateScreenHandler> ();
//		rotateScreenHandler.closeRotateScreen ();

//		helper.changeWandColors (helper.selectMode);

//		setCurrentMode(HelperFuncScript.selectMode);

		OnTrackingLost ();
	}
	
	// Update is called once per frame
	void Update () {

		//Here send RayCast from sphere 

//		RaycastHit hit;
//
//		Ray landingRay = new Ray (RemoteSphere.transform.position, Vector3.forward);
//		Debug.Log (helper.getCurrentMode ());
//		Gizmos.color = Color.red;
//		Debug.DrawRay (RemoteSphere.transform.position, Vector3.forward * rayLength,Color.red,1000f);
//		Gizmos.DrawRay (RemoteSphere.transform.position, Vector3.forward);
			
		if (isRendered) 
		{
//			laser.enabled = true;

			//Check for long raycast
//			Vector3 endPosition = RemoteSphere.transform.position + (rayLength * Vector3.forward);
//
////			Check for long raycast
//
////			if (Physics.Raycast (landingRay, out hit, rayLength)) 
//			if (Physics.SphereCast(landingRay,laserWidth, out hit,rayLength))
//			{
//				endPosition = hit.point;
//
//				if (hit.collider.tag == "capsule") 
//				{
////					rover.GetComponent<MeshRenderer> ().material.color = Color.red;
//					capsule.GetComponent<Renderer>().material.color = Color.red;
//
////					foreach (Transform child in rover.GetComponent<Transform>()) {
////						child.gameObject.GetComponent<Renderer> ().material.color = Color.red;
////					}
//
//					Debug.Log ("Capsule hit");
//
//				}
//			}
//			checkForHit();

//			laser.SetPosition (0, RemoteSphere.transform.position);
//			laser.SetPosition (1, endPosition);
		}
	}

	public void OnTrackableStateChanged(TrackableBehaviour.Status previousStatus, TrackableBehaviour.Status newStatus)
	{
		if (newStatus == TrackableBehaviour.Status.DETECTED || newStatus == TrackableBehaviour.Status.TRACKED) {
			OnTrackingFound ();
		} 

		else 
		{
			OnTrackingLost ();
		}
	}

	private void OnTrackingFound()
	{
		Renderer[] rendererComponents = GetComponentsInChildren<Renderer> ();

		foreach (Renderer component in rendererComponents) {
			component.enabled = true;
		}

		Debug.Log ("Trackable" + mTrackableBehavior.TrackableName + " found");

		isRendered = true;

	}

	private void OnTrackingLost()
	{
		Renderer[] rendererComponents = GetComponentsInChildren<Renderer> ();

		foreach (Renderer component in rendererComponents) {
			component.enabled = false;
		}

		Debug.Log ("Trackable" + mTrackableBehavior.TrackableName + " lost");

		isRendered = false;

	}

	private void checkForHit()
	{
		RaycastHit hit;

		Ray landingRay = new Ray (RemoteSphere.transform.position, Vector3.forward);
		Vector3 endPosition = RemoteSphere.transform.position + (rayLength * Vector3.forward);

		//			Check for long raycast

		//			if (Physics.Raycast (landingRay, out hit, rayLength)) 
		if (Physics.SphereCast(landingRay,laserWidth, out hit,rayLength))
		{
			endPosition = hit.point;

			if (hit.collider.tag.Contains("animal"))
			{
				GameObject prevObj = helper.getCurrentObject ();
				GameObject curObj = hit.transform.gameObject;

				string curMode = helper.getCurrentMode ();

				print (curObj.name);
				helper.setCurrentObject (curObj);

//				Previous object can be - none, same obj, different obj 

//				If same deselect and close menu - curr, none - revert to OG color
				if (curObj == prevObj) 
				{
					helper.setCurrentObject (null);
					helper.changeObjectColor (curObj, helper.getOriginalColor (curObj));
					selectionScreenHandler.closeItemSelectionScreen ();
				}

//				If null select and open menu - curr, this - new color
				if (prevObj == null) 
				{
					helper.setCurrentObject (curObj);
					selectionScreenHandler.showItemSelectionScreen ();
				}

//				If diff select and keep menu - curr,new - new color and revert old 
				if (curObj != prevObj && prevObj != null) 
				{
					helper.setCurrentObject (curObj);
					helper.changeObjectColor (prevObj, helper.getOriginalColor (prevObj));
				}
				
				//					rover.GetComponent<MeshRenderer> ().material.color = Color.red;
//				capsule.GetComponent<Renderer>().material.color = Color.red;

				//					foreach (Transform child in rover.GetComponent<Transform>()) {
				//						child.gameObject.GetComponent<Renderer> ().material.color = Color.red;
				//					}

//				Debug.Log ("Capsule hit");

			}
		}
	}

	private void checkForHit2()
	{

	}

}
