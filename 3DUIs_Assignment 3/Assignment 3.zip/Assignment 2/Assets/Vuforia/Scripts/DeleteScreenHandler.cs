﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeleteScreenHandler : MonoBehaviour {

	private Canvas deleteScreen;
	private SelectionScreenHandler selectionScreenHandler;
	private HelperFuncScript helper;
	private GameObject Remote;
	private GameObject Board;
	private AssemblySpaceHandler assemblySpace;

	// Use this for initialization
	void Start () {
		deleteScreen = this.GetComponent<Canvas> ();
		deleteScreen.enabled = false;
		Remote = GameObject.Find ("Remote");
		Board = GameObject.Find ("Board");
		selectionScreenHandler = GameObject.Find ("ItemSelectedCanvas").GetComponent<SelectionScreenHandler> ();
		helper = GameObject.Find("Remote").GetComponent<HelperFuncScript>();
		assemblySpace = GameObject.Find ("AssemblySpace").GetComponent<AssemblySpaceHandler> ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void showDeleteScreen()
	{
		deleteScreen.enabled = true;
	}

	public void closeDeleteScreen()
	{
		deleteScreen.enabled = false;
	}

	public void startDeleteMode()
	{
		//Close selection screen
		selectionScreenHandler.closeItemSelectionScreen();

		//Open this screen
		showDeleteScreen();

		//Set the current mode
		helper.setCurrentMode(helper.deleteMode);

		//Change the object's color
		helper.changeObjectColor(helper.getCurrentObject(),helper.deleteModeColor);
	}

	public void endDeleteMode()
	{
		//Close this screen
		closeDeleteScreen();

		//Set back to selection mode
		helper.setCurrentMode(helper.selectMode);

		//Revert object to original color
		helper.changeObjectColor(helper.getCurrentObject(),helper.getOriginalColor(helper.getCurrentObject()));

		//Set current object to null
		helper.setCurrentObject(null);
	}

	public void deleteObject()
	{
		Destroy (helper.getCurrentObject ());

		if (helper.getCurWorkSpace () == helper.assemblySpace) {
			assemblySpace.updateFirstObject ();
		}
		endDeleteMode ();
	}
}
