﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Vuforia;

public class BeenTracked : MonoBehaviour, ITrackableEventHandler{

	private TrackableBehaviour mTrackableBehaviour;
	public WalkthroughScript WTS;

	// Use this for initialization
	void Start () {

		mTrackableBehaviour = GetComponent<TrackableBehaviour>();
		if (mTrackableBehaviour)
		{
			mTrackableBehaviour.RegisterTrackableEventHandler(this);
		}

	}

	// Update is called once per frame
	void Update () {

	}

	public void OnTrackableStateChanged(
		TrackableBehaviour.Status previousStatus,
		TrackableBehaviour.Status newStatus)
	{
		if (newStatus == TrackableBehaviour.Status.DETECTED ||
			newStatus == TrackableBehaviour.Status.TRACKED ||
			newStatus == TrackableBehaviour.Status.EXTENDED_TRACKED)
		{
			// Play audio when target is found
			if(this.tag.Contains("Mordant")){
				try{
				WTS.MF = true;
				}
				catch{
					Debug.Log ("HEre");
				}
			} else if(this.tag.Contains("Hammer")){
				WTS.HammerFound=true;
			} else if(this.tag.Contains("Spatula")) {
				WTS.SpatulaFound=true;
			} 
		}

	}   
}

