﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class recipieScript : IngriedientScript {

	public GameObject dye;
	public GameObject mordant;

	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {

	}
}



