﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LabScript : MonoBehaviour {

	WalkthroughScript walkthroughScript;
	GameObject ErrorScreen;

	// Use this for initialization
	void Start () {
		walkthroughScript = GameObject.Find ("Light").GetComponent<WalkthroughScript> ();
		ErrorScreen = GameObject.Find ("ErrorScreen");
		ErrorScreen.SetActive (false);
	}

    void OnTriggerEnter(Collider other)
    {
      
		if (other.tag.Contains("Mordant") && walkthroughScript.mordantRetrieved == false)
        {
            Debug.Log("cylinder entered");

			if ((walkthroughScript.getMode () != walkthroughScript.walkthroughMode) || walkthroughScript.currentStep != walkthroughScript.step1) {
				ErrorScreen.SetActive (true);
			}

			//Update images 

			else {
				walkthroughScript.setStep (walkthroughScript.step1B);
			}
        }

		if (other.tag.Contains ("Hammer") && walkthroughScript.hammerRetrieved == false) {
			Debug.Log ("Hammer entered");

			if ((walkthroughScript.getMode () != walkthroughScript.walkthroughMode) || walkthroughScript.currentStep != walkthroughScript.step2) {
				ErrorScreen.SetActive (true);
			} else {
				walkthroughScript.setStep (walkthroughScript.step2B);
			}
		}

		if (other.tag.Contains ("Spatula") && walkthroughScript.spatulaRetrieved == false) {

			if ((walkthroughScript.getMode () != walkthroughScript.walkthroughMode) || walkthroughScript.currentStep != walkthroughScript.step3) {
				ErrorScreen.SetActive (true);
			} else {
				walkthroughScript.setStep (walkthroughScript.step3B);
			}
		}
    }


    // Update is called once per frame
    void Update () {
		
	}
}
