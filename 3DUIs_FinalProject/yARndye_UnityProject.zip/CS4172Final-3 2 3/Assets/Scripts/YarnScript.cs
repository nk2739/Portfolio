﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class YarnScript : MonoBehaviour {

	WalkthroughScript walkthroughScript;
	GameObject Yarn;
	Material BeakerMaterial;
	GameObject Hanger;

	// Use this for initialization
	void Start () {
		walkthroughScript = GameObject.Find ("Light").GetComponent<WalkthroughScript> ();
		Yarn = GameObject.Find ("Yarn");
		BeakerMaterial = (Material)Resources.Load ("Beaker2Material");
		Hanger = GameObject.Find ("Hanger");
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerEnter(Collider other) {

		if (other.tag.Contains ("beaker")) {

			Debug.Log ("Yarn Dyed");

			walkthroughScript.yarnDyed = true;

			//Recolor yarn
			foreach (Transform child in Yarn.transform) {
				child.gameObject.GetComponent<Renderer> ().material = BeakerMaterial;
			}

		}

		if (walkthroughScript.yarnDyed == true) {

			if (other.tag.Contains("hanger")) {
				switchObjectParent (Yarn);
				walkthroughScript.showStepCompleteScreen (walkthroughScript.step4);
				walkthroughScript.stepsComplete = true;
			}
		}
	}

	//Switches object parent to translate the object
	void switchObjectParent(GameObject curObj)
	{
		curObj.GetComponentInParent<Transform> ().parent = Hanger.transform;

		//Freeze object rotation
		curObj.GetComponent<Rigidbody>().freezeRotation = true;
	}
}
