﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpatulaScript : MonoBehaviour {

	WalkthroughScript walkthroughScript;
	private static int numCollisions;
	public bool beakerStirred;
	private GameObject Lab;

	// Use this for initialization
	void Start () {
		walkthroughScript = GameObject.Find ("Light").GetComponent<WalkthroughScript> ();
		numCollisions = 0;
		beakerStirred = false;
		Lab = GameObject.Find ("Lab");
	}

	// Update is called once per frame
	void Update () {

	}

	void OnCollisionEnter(Collision collision) {
		Debug.Log (collision.collider.tag);
	}

	void OnCollisionStay(Collision collision){

		bool spatulaRetrieved = walkthroughScript.spatulaRetrieved;

		if (collision.collider.tag.Contains("beaker")) {
			if (spatulaRetrieved == true && beakerStirred == false) {
				numCollisions++;
				Debug.Log ("Stirring");

				if (numCollisions >= 50) {
					beakerStirred = true;
					Debug.Log ("Stirring done.");

					if (walkthroughScript.beakerLit == true) {
						walkthroughScript.setStep (walkthroughScript.step4);
					}
				}
			}
		}

	}

	void OnCollisionExit(Collision collision){

	}

	void OnTriggerEnter(Collider other) {

		if (walkthroughScript.spatulaRetrieved == true && other.tag.Contains ("heat")) {
			walkthroughScript.beakerLit = true;

			Debug.Log ("Lit fire");

			//Show fire animation
			Lab.GetComponent<ParticleSystem>().Play();

			if (beakerStirred == true) {
				walkthroughScript.showStepCompleteScreen (walkthroughScript.step3);
				walkthroughScript.setStep (walkthroughScript.step4);
			}
		}
	}

	void OnTriggerStay(Collider other) {
		bool spatulaRetrieved = walkthroughScript.spatulaRetrieved;

		if (other.tag.Contains("beaker")) {
			if (spatulaRetrieved == true && beakerStirred == false) {
				numCollisions++;
				Debug.Log ("Stirring");

				if (numCollisions >= 150) {
					beakerStirred = true;
					Debug.Log ("Stirring done.");

					if (walkthroughScript.beakerLit == true) {
						walkthroughScript.showStepCompleteScreen (walkthroughScript.step3);
						walkthroughScript.setStep (walkthroughScript.step4);
					}
				}
			}
		}
	}

	void OnTriggerExit(Collider other) {

	}
}
