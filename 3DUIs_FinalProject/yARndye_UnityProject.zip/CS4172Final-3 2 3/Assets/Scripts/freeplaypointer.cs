﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class freeplaypointer : MonoBehaviour {
	public freeplaysteptracker steptrackerscript;
	public GameObject cnvs;
	// Use this for initialization
	void Start () {
		steptrackerscript = GameObject.Find("ARCamera").GetComponent<freeplaysteptracker>();
	}

	// Update is called once per frame
	void Update () {

	}

	void OnTriggerEnter(Collider other)
	{	Debug.Log ("collision detected");
		if (steptrackerscript.mode == 1)
		{
			if (steptrackerscript.freeplaystepnumber == 0)
			{
				Debug.Log("Step zero collision");
				if (other.tag.Contains("shelf_dye2") && (steptrackerscript.objectselected == 0))
				{
					Debug.Log("WOW");
					Material m_mat = other.gameObject.GetComponent<Renderer>().material;
					m_mat.color = Color.magenta;
					Debug.Log("WOW");
					other.gameObject.transform.parent = transform;
					steptrackerscript.objectselected = 1;
					Debug.Log("object selected");
					steptrackerscript.dyeselected = 2;
					steptrackerscript.Steps(1);
				}
				if (other.tag.Contains("shelf_mordant1") && (steptrackerscript.objectselected == 0))
				{
					other.gameObject.transform.parent = transform;
					steptrackerscript.objectselected = 1;
					Debug.Log("object selected");
					steptrackerscript.mselected = 1;
					steptrackerscript.Steps(1);
				}
				if (other.tag.Contains("shelf_mordant2") && (steptrackerscript.objectselected == 0))
				{
					other.gameObject.transform.parent = transform;
					steptrackerscript.objectselected = 1;
					Debug.Log("object selected");
					steptrackerscript.mselected = 2;
					steptrackerscript.Steps(1);
				}
				if (other.tag.Contains("shelf_dye1") && (steptrackerscript.objectselected == 0))
				{
					Material m_mat = other.gameObject.GetComponent<Renderer>().material;
					m_mat.color = Color.cyan;

					other.gameObject.transform.parent = transform;
					steptrackerscript.objectselected = 1;
					Debug.Log("object selected");
					steptrackerscript.dyeselected = 1;
					steptrackerscript.Steps(1);
				}
			}
			if (steptrackerscript.freeplaystepnumber == 2)
			{
				if (other.tag.Contains("shelf_mordant2") && (steptrackerscript.objectselected == 0) && (steptrackerscript.dyeselected != 0))
				{
					other.gameObject.transform.parent = transform;
					steptrackerscript.objectselected = 1;
					Debug.Log("object selected");
					steptrackerscript.Steps(3);
				}
				if (other.tag.Contains("shelf_mordant1") && (steptrackerscript.objectselected == 0) && (steptrackerscript.dyeselected != 0))
				{
					other.gameObject.transform.parent = transform;
					steptrackerscript.objectselected = 1;
					Debug.Log("object selected");
					steptrackerscript.Steps(3);
				}
				if (other.tag.Contains("shelf_dye1") && (steptrackerscript.objectselected == 0) && (steptrackerscript.mselected != 0))
				{

					Material m_mat = other.gameObject.GetComponent<Renderer>().material;
					m_mat.color = Color.cyan;

					other.gameObject.transform.parent = transform;
					steptrackerscript.objectselected = 1;
					Debug.Log("object selected");
					steptrackerscript.Steps(3);
				}
				if (other.tag.Contains("shelf_dye2") && (steptrackerscript.objectselected == 0) && (steptrackerscript.mselected != 0))
				{
					Material m_mat = other.gameObject.GetComponent<Renderer>().material;
					m_mat.color = Color.magenta;

					other.gameObject.transform.parent = transform;
					steptrackerscript.objectselected = 1;
					Debug.Log("object selected");
					steptrackerscript.Steps(3);
				}
			}

		} 
	}

}


