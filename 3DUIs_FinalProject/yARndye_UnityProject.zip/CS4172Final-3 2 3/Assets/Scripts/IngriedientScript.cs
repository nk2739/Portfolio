﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IngriedientScript : MonoBehaviour {

	public GameObject prefab;
	public Color color;
	public Transform counterpart;
	public string ingName;

	// Use this for initialization
	void Start () {

	}

	public void setColor(Color color){
		this.color = color;
	}
	// Update is called once per frame
	void Update () {

	}
}


