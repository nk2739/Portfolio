﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class WalkthroughScript : MonoBehaviour {
	public GameObject InfoText, InstructionText;
	public Canvas ScanningCanvas, AllSteps;
	public string step1 = "step1";
	public string step1B = "step1B";
	public bool mordantRetrieved;
	private bool Found = false;
	public  bool mordantPoured;
	GameObject Mordant;
	GameObject Hammer;
	GameObject Spatula;

	public bool HammerFound, SpatulaFound;
	public bool MF;
	private int AllFound;
	public Text MordantT, HammerT, SpatulaT, Status;
	public Button ScanConfirm;

	public string step2 = "step2";
	public string step2B = "step2B";
	public bool hammerRetrieved;

	public string step3 = "step3";
	public string step3B = "step3B";
	public bool spatulaRetrieved;
	public bool beakerLit;

	public string step4 = "step4";
	public string step4B = "step4B";
	public bool yarnDyed;

	private string[] step1BItems = new string[] {"Beaker","Pan"};

//	private string[] step2Items = new string[] {"Beaker","Pan","SaltShaker","PaintBucket"};
//	private string[] step2BItems = new string[] {"Beaker","Pan","SaltShaker","PaintBucket"};

	private string[] step2Items = new string[] {"Beaker","Pan","SaltShaker"};
	private string[] step2BItems = new string[] {"Beaker","Pan","SaltShaker"};

	private string[] step3Items = new string[] {"HeatButton","Beaker","Pan","SaltShaker","PaintBucket2"};
	private string[] step3BItems = new string[] {"HeatButton","Beaker","Pan","SaltShaker","PaintBucket2"};

	//Step 4 items - dyed beaker, pan, rope (to hang upon), yarn ball
	private string[] step4Items = new string[] {"Beaker2","Pan","Hanger","Yarn"};

	GameObject InfoQuad;
	GameObject ItemQuad;
	GameObject InstructionQuad;

	GameObject CompletedScreen;
	Text CompletedScreenText;

	GameObject InfoScreen;
	GameObject InfoPopup;
	Text InfoPopupText;

	GameObject StartScreen;

	GameObject Lab;

	public string freePlayMode = "freePlayMode";
	public string walkthroughMode = "walkthroughMode";

	private string curMode;

	Wayfind wayfind;

	public string currentStep;

	public bool stepsComplete;

	SpatulaScript spatulaScript;

	GameObject Arrow;
	GameObject Cylinder;
	GameObject Hand;

	GameObject PaintBucket;

	// Use this for initialization
	void Start () {
		MordantT.enabled = false;
		SpatulaT.enabled = false;
		HammerT.enabled = false;
		ScanningCanvas.enabled = false;
	
		InfoQuad = GameObject.Find("InfoQuad");
		ItemQuad = GameObject.Find("ItemQuad");
		InstructionQuad = GameObject.Find("InstructionQuad");
		Lab = GameObject.Find ("Lab");
//		clearWorkspace (step1);
		mordantRetrieved = false;
		mordantPoured = false;
		spatulaRetrieved = false;
		beakerLit = false;
		Mordant = GameObject.Find ("Mordant");
		Hammer = GameObject.Find ("Hammer");
		Spatula = GameObject.Find ("Spatula");
		spatulaScript = Spatula.GetComponent<SpatulaScript> ();

		StartScreen = GameObject.Find ("StartScreen");

		hammerRetrieved = false;

		CompletedScreen = GameObject.Find ("StepCompletedScreen");

		CompletedScreenText = CompletedScreen.transform.Find ("CompleteScreenText").GetComponent<Text>();
		curMode = "";

		CompletedScreen.SetActive (false);

		wayfind = GameObject.Find ("Arrow").GetComponent<Wayfind> ();

		yarnDyed = false;

		currentStep = "";

		stepsComplete = false;

		InfoScreen = GameObject.Find ("InfoScreen");
		InfoScreen.SetActive (false);

		InfoPopup = GameObject.Find ("InfoPopup");
		InfoPopupText = InfoPopup.transform.Find ("InfoPopupText").GetComponent<Text> ();
		InfoPopup.SetActive (false);

		//Initially hide everything
		clearWorkspace(step1);
		hideQuads ();

		Arrow = GameObject.Find ("Arrow");
		Cylinder = GameObject.Find ("Cylinder");
		Hand = GameObject.Find ("Hand");

		Arrow.SetActive (false);
		Cylinder.SetActive (false);
		Hand.SetActive (false);

		PaintBucket = GameObject.Find ("PaintBucket");
		PaintBucket.SetActive (false);
	}
	
	// Update is called once per frame
	void Update () {
		//onMordantRotation ();
		if (MF) {
			MordantT.text = "Mordant Found";
			MordantT.color = Color.green;
		} if (HammerFound) {
			HammerT.text = "Hammer Found";
			HammerT.color = Color.green;
		}if (SpatulaFound) {
			SpatulaT.text = "Spatula Found";
			SpatulaT.color = Color.green;
		}

		if (MF && HammerFound && SpatulaFound) {
			Status.text = "All Cylinder Targets Found!";

			Status.enabled = true;
			ScanConfirm.GetComponentInChildren<Text> ().text = "Start Walkthrough";
			ScanConfirm.gameObject.SetActive (true);

			MordantT.enabled = false;
			SpatulaT.enabled = false;
			HammerT.enabled = false;

			MordantT.color = Color.red;
			HammerT.color = Color.red;
			SpatulaT.color = Color.red;

			MordantT.text = "Mordant Not Found";
			HammerT.text = "Hammer Not Found";
			SpatulaT.text = "Spatula Not Found";
		}
	}

	public void StartScanOnClick(){
		if (!Found) {
			Debug.Log ("found");
			Found = true;
			ScanConfirm.gameObject.SetActive (false);
			Status.enabled = false;
			MordantT.enabled = true;
			SpatulaT.enabled = true;
			HammerT.enabled = true;
		} else {
			Found = false;
			ScanningCanvas.enabled = false;
			InfoScreen.SetActive (true);
		}
	}
		
	public void setStep(string curStep) 
	{
		currentStep = curStep;

		if (curStep == step1) {
			Debug.Log("step 1 ran");
			GameObject Look = GameObject.FindGameObjectWithTag ("Mordant");
			wayfind.activateWand (Look);
		}

		if (curStep == step2) {
			GameObject Look = GameObject.FindGameObjectWithTag ("Hammer");
			PaintBucket.SetActive (true);
			wayfind.activateWand (Look);
		}

		if (curStep == step3) {
			GameObject Look = GameObject.FindGameObjectWithTag ("Spatula");
			wayfind.activateWand (Look);
		}

		if (curStep == step4) {
			wayfind.MordantCollision ();
		}

		clearWorkspace (curStep);
		updateWorkspace(curStep);
		updateScreens (curStep);
	}

	public void setMode(string mode)
	{
		curMode = mode;
	}

	public string getMode()
	{
		return curMode;
	}

	public void initializeWalkthroughBoard()
	{
		Mordant.SetActive (true);
		Hammer.SetActive (true);
		Spatula.SetActive (true);
		showQuads ();
		setStep (step1);
		setMode (walkthroughMode);
//		InfoScreen.SetActive (true);
		ScanningCanvas.enabled = true;
	}

	private void updateWorkspace(string curStep)
	{
		string[] curItems = new string[] {};
			
		if (curStep == step1B) {
			curItems = step1BItems;
			mordantRetrieved = true;
		}

		if (curStep == step2) {
			//Includes mordant in beaker 
			curItems = step2Items;
			Debug.Log ("updating 2");
		}

		if (curStep == step2B) {
			curItems = step2BItems;
			hammerRetrieved = true;
		}

		if (curStep == step3) {
			curItems = step3Items;
		}

		if (curStep == step3B) {
			curItems = step3BItems;
			spatulaRetrieved = true;
		}

		if (curStep == step4) {
			curItems = step4Items;
		}

		foreach(string item in curItems) {
			Lab.transform.Find (item).gameObject.SetActive (true);
		}
	}

	private void updateScreens(string curStep)
	{
		string infoText = "";
		string instructionText = "";
		Material itemMaterial = (Material)Resources.Load ("step1a");
	
		if (curStep == step1) {
			infoText = "Mordant emulsifies" + "\n" + "the dye"; 
			instructionText = "Step 1:" + "\n" + "Retrieve the Mordant"; 
		}

		if (curStep == step1B) {
			infoText = "Pouring the mordant" + "\n" + "creates the base layer"; 
			instructionText = "Pour the mordant" + "\n" + "into the beaker"; 
			itemMaterial = (Material)Resources.Load ("step1b");
		}

		if (curStep == step2) {
			infoText = "The Hammer is needed" + "\n" + "to crush the dye"; 
			instructionText = "Step 2:" + "\n" + "Retrieve the Hammer";
			itemMaterial = (Material)Resources.Load ("step2a");
			GameObject.Find ("PaintBucket").GetComponent<Renderer> ().material = (Material)Resources.Load ("Beaker2Material");
		}

		if (curStep == step2B) {
			infoText = "The crushed dye" + "\n" + "will mix well with the mordant"; 
			instructionText = "Crush the dye" + "\n" + "with the Hammer";
			itemMaterial = (Material)Resources.Load ("step2b");
		}

		if (curStep == step3) {
			infoText = "We need to mix" + "\n" + "the dye and mordant further"; 
			instructionText = "Step 3: " + "\n" + "Retrieve the Mixer";
			itemMaterial = (Material)Resources.Load ("step3a");
		}

		if (curStep == step3B) {
			infoText = "Heating and mixing" + "\n" + "will stick the dye to the yarn"; 
			instructionText = "Light the fire" + "\n" + "then mix using the Mixer";
			itemMaterial = (Material)Resources.Load ("step3b");

		}

		if (curStep == step4) {
			infoText = "Now the yarn can" + "\n" + "soak the dye and keep the color"; 
			instructionText = "Dye the yarn" + "\n" + "then hang it to dry";
			itemMaterial = (Material)Resources.Load ("step4");

		}
		//Update Info and Instruction Texts	

		InfoText.GetComponent<TextMesh>().text = infoText;
		InstructionText.GetComponent<TextMesh> ().text = instructionText;
		ItemQuad.GetComponent<Renderer>().material = itemMaterial;
	}

	public void clearWorkspace(string curStep)
	{
		foreach (Transform child in Lab.transform) {
			if (child.tag.Contains("lab")) {
				child.gameObject.SetActive (false);
			}
		}
	}

	public void onMordantRotation()
	{
		if (mordantRetrieved == true && mordantPoured == false) {
			//Debug.Log (Mordant.transform.rotation.eulerAngles);
//			mordantPoured = true;

			if (Mordant.transform.rotation.eulerAngles.y < 100) {
				mordantPoured = true;

				Debug.Log ("Mordant poured");

				//Play particle animation 
				Mordant.GetComponent<ParticleSystem>().Play();
				Mordant.GetComponent<ParticleSystem>().enableEmission = true;

				//Deactivate mordant game object (don't track anymore)


				//Show 2D Congratualations screen - close on 'OK'. 
				showStepCompleteScreen(step1);

				//Initiate step 2 and show Step 2 screen. 
				setStep(step2);

			}
		}
	}

	public void showStepCompleteScreen(string curStep)
	{
		string message = "";

		if (curStep == step1) {
			message = "Nice! You have completed Step 1: Pouring the Mordant into the Beaker. Now " +
			"you can continue on to Step 2.";
		}

		if (curStep == step2) {
			message = "Great! You have completed Step 2: Adding the Dye to the Mordant. Now " +
				"you can continue on to Step 3.";
		}

		if (curStep == step3) {
			message = "Awesome! You have completed Step 3: Heating and Mixing the Solution. Now " +
				"you can continue on to Step 4.";
		}

		if (curStep == step4) {
			message = "Congratulations! You have completed learning how to dye yarn!";
		}

		//Set Message
		CompletedScreenText.text = message;

		CompletedScreen.SetActive (true);
	}

	void hideQuads() {
		InfoQuad.SetActive(false);
		ItemQuad.SetActive(false);
		InstructionQuad.SetActive(false);
	}

	void showQuads(){
		InfoQuad.SetActive(true);
		ItemQuad.SetActive(true);
		InstructionQuad.SetActive(true);
	}

	public void reactivateScene() {

		//Reset all vars and objects
		//Show start screen
		if (stepsComplete == true) {
//			mordantRetrieved = false;
//			mordantPoured = false;
//			spatulaRetrieved = false;
//			beakerLit = false;
//			hammerRetrieved = false;
//			yarnDyed = false;
//			stepsComplete = false;
//			spatulaScript.beakerStirred = false;
//			Hammer.SetActive (true);
//			Spatula.SetActive (true);
////			Mordant.SetActive (true);
//			clearWorkspace(step1);
//			hideQuads ();
//			InfoScreen.SetActive (false);
//			StartScreen.SetActive (true);

			reloadScene ();
		}
	}

	public void deactivateTarget() {
		
		if (currentStep == step2) {
			Mordant.SetActive (false);
		}

		if (currentStep == step3) {
			Hammer.SetActive (false);
		}

		if (currentStep == step4) {
			Spatula.SetActive (false);
		}
	}
		
	public void showStepInformation(){

		string info = "";

		if (currentStep == step1 || currentStep == step1B) {
			info = "In Step 1, you get Mordant, which ensures the dye sticks to the yarn. " +
			"Some natural mordants include Alum, Iron, or Copper. Be careful by using gloves!";
		}

		if (currentStep == step2 || currentStep == step2B) {
			info = "For Step 2, you need a Hammer to crush the Dye. " +
				"The Dye needs maximum surface area to fix itself to the Mordant and create the Dye Bath.";
		}
		if (currentStep == step3 || currentStep == step3B) {
			info = "Now in Step 3, you need the Mixer to ensure an even Dye Bath. " +
				"Heating the Bath allows the Dye to stick to the Yarn, so slowly raise the temperature to 180.";
		}
		if (currentStep == step4) {
			info = "Finally, Step 4 asks you to place your Yarn in the Dye Bath, soaking the colors. " +
				"The Dye needs enough time to settle, so place your Dyed Yarn to hang and you're done!";
		}

		InfoPopupText.text = info;
		InfoPopup.SetActive (true);
	}

	public void reloadScene() {
		string currentSceneName = SceneManager.GetActiveScene ().name;
		SceneManager.LoadScene (currentSceneName);
	}

	public void ShowAllSteps(){
		AllSteps.gameObject.SetActive (true);
	}
}
