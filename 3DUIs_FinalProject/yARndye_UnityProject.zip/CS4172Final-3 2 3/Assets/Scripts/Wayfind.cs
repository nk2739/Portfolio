﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wayfind : MonoBehaviour {
	
	public GameObject Look, Cylinder, Arrow;

	public bool wandActivated, SetIP, WandTracking = false;
	public GameObject LookAt, Percentage, Wand;
	public Vector3 InitialPos;
	public float Dist;
	public Vector3 WLoc;
	WalkthroughScript walkthroughScript;

	// Use this for initialization
	void Start () {
//		Look = GameObject.FindGameObjectWithTag ("Mordant");
		Percentage.SetActive(false);
		wandActivated = false;
		walkthroughScript = GameObject.Find ("Light").GetComponent<WalkthroughScript> ();
//		Cylinder = GameObject.Find ("Cylinder");
//		Arrow = GameObject.Find ("Arrow");
	}

	public void activateWand(GameObject toLookAt)
	{
		Cylinder.SetActive (false);
		Arrow.SetActive (true);
		wandActivated = true;
		LookAt = toLookAt;
		Percentage.SetActive(true);

	}

	// Update is called once per frame
	void Update () {
//		Debug.Log (LookAt.transform.position);
		string curMode = walkthroughScript.getMode ();
		if (wandActivated == true && curMode == walkthroughScript.walkthroughMode) {
			if (!SetIP) {
//				Debug.Log (WandTracking);
				if (WandTracking) {
					InitialPos = WLoc;
					SetIP = true;
					Dist = Vector3.Distance (WLoc, LookAt.transform.position);
				}
			}

			float Perc = Vector3.Distance (WLoc, LookAt.transform.position)/Dist;
			float Display = Mathf.RoundToInt (Perc * 100f);
			if (Display<0) {
					Percentage.GetComponent<TextMesh> ().text = 0.ToString () + "%";
			} else if (Display>100){
				Percentage.GetComponent<TextMesh> ().text = 100.ToString() + "%";
			} else {
				Percentage.GetComponent<TextMesh> ().text = Display.ToString () + "%";
			}
//			Debug.Log ("Looking at:" + LookAt.transform.tag);
			this.transform.LookAt (LookAt.transform);

		}
	}


	public void MordantCollision(){
		Percentage.SetActive (false);
		Cylinder.SetActive (true);
		Arrow.SetActive (false);
		wandActivated = false;
		InitialPos = Vector3.negativeInfinity;
		Percentage.ToString ();
	}

}
