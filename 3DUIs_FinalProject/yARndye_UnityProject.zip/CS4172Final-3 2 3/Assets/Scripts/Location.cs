﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Vuforia;

public class Location : MonoBehaviour, ITrackableEventHandler{

	private ImageTargetBehaviour mImageTargetBehaviour = null;
	private TrackableBehaviour mTrackableBehaviour;
	public PlaneMovement InfoPlaneController;
	public PlaneMovement ItemPlaneController;
	public PlaneMovement InstructionPlaneController;
	public Wayfind Wayfinder;

	// Use this for initialization
	void Start () {
		mImageTargetBehaviour = GetComponent<ImageTargetBehaviour>();

		mTrackableBehaviour = GetComponent<TrackableBehaviour>();
		if (mTrackableBehaviour)
		{
			mTrackableBehaviour.RegisterTrackableEventHandler(this);
		}

	}

	// Update is called once per frame
	void Update () {
		if (mImageTargetBehaviour == null)
		{
			Debug.Log ("ImageTargetBehaviour not found");
			return;
		}

		Vector3 pointOnTarget = new Vector3(0,0, .5f); 
				Vector3 targetPointInWorldRef = transform.TransformPoint(pointOnTarget);

		InfoPlaneController.WLoc = targetPointInWorldRef;
		ItemPlaneController.WLoc = targetPointInWorldRef;
		InstructionPlaneController.WLoc = targetPointInWorldRef;

		pointOnTarget = new Vector3(0,0f, .5f); 

		targetPointInWorldRef = transform.TransformPoint(pointOnTarget);

		Wayfinder.WLoc = targetPointInWorldRef;
	}

	public void OnTrackableStateChanged(
		TrackableBehaviour.Status previousStatus,
		TrackableBehaviour.Status newStatus)
	{
		if (newStatus == TrackableBehaviour.Status.DETECTED ||
			newStatus == TrackableBehaviour.Status.TRACKED ||
			newStatus == TrackableBehaviour.Status.EXTENDED_TRACKED)
		{
			// Play audio when target is found
			Wayfinder.WandTracking = true;
		}
		else
		{
			// Stop audio when target is lost
			Wayfinder.WandTracking = false;
		}
	}   
}

