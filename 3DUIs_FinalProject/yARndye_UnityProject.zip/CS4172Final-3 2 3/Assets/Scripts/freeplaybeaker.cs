﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class freeplaybeaker : MonoBehaviour {
	public freeplaysteptracker steptrackerscript;
	public GameObject cnvs;
	public Text winText;
    WalkthroughScript ws;
    GameObject Mordant;

	public Text DyeText, MordantText;

	// Use this for initialization
	void Start () {
		steptrackerscript = GameObject.Find("ARCamera").GetComponent<freeplaysteptracker>();
//		DyeText = GameObject.Find ("DyeAddedText").GetComponent<Text> ();
//		MordantText = GameObject.Find ("MordantAddedText").GetComponent<Text> ();
		DyeText.text = "";
        MordantText.text = "";
        ws = GameObject.Find("Light").GetComponent<WalkthroughScript>();
        Mordant = GameObject.Find("Mordant");
	}

	void OnTriggerEnter(Collider other)
	{

        if (other.tag.Contains("mtop"))
        {
            Debug.Log("yo yo yo!!");
            if (ws.mordantRetrieved == true && ws.mordantPoured == false)
            {
                //Debug.Log (Mordant.transform.rotation.eulerAngles);
                //			mordantPoured = true;


                ws.mordantPoured = true;

                Debug.Log("Mordant poured");

                //Play particle animation 
                Mordant.GetComponent<ParticleSystem>().Play();
                Mordant.GetComponent<ParticleSystem>().enableEmission = true;

                //Deactivate mordant game object (don't track anymore)


                //Show 2D Congratualations screen - close on 'OK'. 
                ws.showStepCompleteScreen(ws.step1);

                //Initiate step 2 and show Step 2 screen. 
                ws.setStep(ws.step2);

            }
        }


        if (steptrackerscript.mode == 1)
		{
            
                

			if (steptrackerscript.freeplaystepnumber == 1)
			{   
				Debug.Log("Step one collision");
				Debug.Log(other.tag);
				if (other.tag.Contains("shelf_dye1") && (steptrackerscript.objectselected == 1))
				{
					steptrackerscript.thisadded = other.gameObject;
					other.gameObject.SetActive(false);
					steptrackerscript.objectselected = 0;
					Debug.Log("dye added");
					//steptrackerscript.dyeselected = 1;
					steptrackerscript.Steps(2);
					Debug.Log (DyeText);
//					DyeText.enabled = true;
					DyeText.text = "Dye Added";
				}
				if (other.tag.Contains("shelf_dye2") && (steptrackerscript.objectselected == 1))
				{
					steptrackerscript.thisadded = other.gameObject;
					other.gameObject.SetActive(false);
					steptrackerscript.objectselected = 0;
					Debug.Log("dye added");
					//steptrackerscript.dyeselected = 2;
					steptrackerscript.Steps(2);
					Debug.Log (DyeText);
//					DyeText.text = "huihuihiu";
//					DyeText.enabled = true;
					DyeText.text = "Dye Added";
				}
				if (other.tag.Contains("shelf_mordant2") && (steptrackerscript.objectselected == 1))
				{
					steptrackerscript.thisadded = other.gameObject;
					other.gameObject.SetActive(false);
					steptrackerscript.objectselected = 0;
					Debug.Log("dye added");
					//steptrackerscript.dyeselected = 1;
					steptrackerscript.Steps(2);
//					DyeText.text = "huihuihiu";
//					MordantText.enabled = true;
					MordantText.text = "Mordant Added";
				}
				if (other.tag.Contains("shelf_mordant1") && (steptrackerscript.objectselected == 1))
				{
					steptrackerscript.thisadded = other.gameObject;
					other.gameObject.SetActive(false);
					steptrackerscript.objectselected = 0;
					Debug.Log("dye added");
					//steptrackerscript.dyeselected = 1;
					steptrackerscript.Steps(2);
//					MordantText.enabled = true;
					MordantText.text = "Mordant Added";
				}
			}
			if (steptrackerscript.freeplaystepnumber == 3)
			{
				Debug.Log("Step one collision");
				Debug.Log(other.tag);
				if (other.tag.Contains("shelf_mordant1") && (steptrackerscript.objectselected == 1))
				{
					other.gameObject.SetActive(false);
					steptrackerscript.objectselected = 0;
					Debug.Log("mordant added");
					if (steptrackerscript.dyeselected == 1)
					{
						Material m_mat = GetComponent<Renderer>().material;
						m_mat.color = Color.blue;

						cnvs.SetActive(true);
						winText.text = "Blue Lake was created!";
//						MordantText.enabled = true;
						MordantText.text = "Mordant Added";
					}
					else
					{
						cnvs.SetActive(true);
						winText.text = "No color was made.";
						Debug.Log("no color");
//						MordantText.enabled = true;
						MordantText.text = "Mordant Added";
					}
				}
				if (other.tag.Contains("shelf_mordant2") && (steptrackerscript.objectselected == 1))
				{
					other.gameObject.SetActive(false);
					steptrackerscript.objectselected = 0;
					Debug.Log("mordant added");
					if (steptrackerscript.dyeselected == 2)
					{
						Material m_mat = GetComponent<Renderer>().material;
						m_mat.color = Color.red;
						cnvs.SetActive(true);
						winText.text = "Madder Red was created!";
//						MordantText.enabled = true;
						MordantText.text = "Mordant Added";
					}
					else
					{
						cnvs.SetActive(true);
						winText.text = "No color was made.";
						Debug.Log("no color");
//						MordantText.enabled = true;
						MordantText.text = "Mordant Added";
					}
				}
				if (other.tag.Contains("shelf_dye2") && (steptrackerscript.objectselected == 1))
				{
					other.gameObject.SetActive(false);
					steptrackerscript.objectselected = 0;
					Debug.Log("LAST STEP");
					if (steptrackerscript.mselected == 2)
					{
						Material m_mat = GetComponent<Renderer>().material;
						m_mat.color = Color.red;
						cnvs.SetActive(true);
						winText.text = "Madder Red was created!";
//						DyeText.enabled = true;
						DyeText.text = "Dye Added";
					}
					else
					{
						cnvs.SetActive(true);
						winText.text = "No color was made.";
						Debug.Log("no color");
//						DyeText.enabled = true;
						DyeText.text = "Dye Added";
					}

				}
				if (other.tag.Contains("shelf_dye1") && (steptrackerscript.objectselected == 1))
				{
					other.gameObject.SetActive(false);
					steptrackerscript.objectselected = 0;
					Debug.Log("mordant added");
					if (steptrackerscript.mselected == 1)
					{
						Material m_mat = GetComponent<Renderer>().material;
						m_mat.color = Color.blue;
						cnvs.SetActive(true);
						winText.text = "Blue Lake was created!";
//						DyeText.enabled = true;
						DyeText.text = "Dye Added";
					}
					else
					{
						cnvs.SetActive(true);
						winText.text = "No color was made.";
						Debug.Log("no color");
//						DyeText.enabled = true;
						DyeText.text = "Dye Added";
					}
				}
			}
		}
	}
	// Update is called once per frame
	void Update () {

	}
}



