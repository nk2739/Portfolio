﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class freeplaysteptracker : MonoBehaviour {
	public int freeplaystepnumber = 0;
	public int mode =0;
	public int objectselected = 0;
	public int mordantselected = 0;
	public int dyeselected = 0;
	public int mselected = 0;
	public Material Water;
	public GameObject cnvs;

	public GameObject paint1;
	public GameObject paint2;
	public GameObject mordant1;
	public GameObject mordant2;
	public GameObject shelf1;
	public GameObject shelf2;
	public Component[] mordantcomps;
	PointerScript pointerScript;
	public GameObject thisadded;
	GameObject Shelf;
	GameObject Shelf2;
	GameObject Arrow;
	GameObject Beaker;
	GameObject Cylinder;
	GameObject Hand;

	WalkthroughScript walkthroughScript;

	GameObject ExitFreePlayScreen;
	GameObject ConfirmExitScreen;
	GameObject StartScreen;

	public Text DyeText,MordantText;

	public void startover()
	{
//		DyeText = GameObject.Find ("DyeAddedText").GetComponent<Text> ();
//		MordantText = GameObject.Find ("MordantAddedText").GetComponent<Text> ();

		dyeselected = 0;
		mselected = 0;
		objectselected = 0;
		Beaker.GetComponent<Renderer> ().material = Water;
		freeplaystepnumber = 0;
		cnvs.SetActive(false);
		paint1.SetActive(true);
		paint1.transform.parent = shelf1.transform;
		paint1.GetComponent<MeshRenderer>().enabled = true;
		paint1.GetComponent<SphereCollider>().enabled = true;
		Material m_mat = paint1.gameObject.GetComponent<Renderer>().material;
		m_mat.color = Color.blue;

		paint2.SetActive(true);
		paint2.transform.parent = shelf1.transform;
		paint2.GetComponent<MeshRenderer>().enabled = true;
		paint2.GetComponent<SphereCollider>().enabled = true;
		Material m_mat2 = paint2.gameObject.GetComponent<Renderer>().material;
		m_mat2.color = Color.red;

		mordant1.SetActive(true);
		mordant1.transform.parent = shelf2.transform;
		mordant1.transform.GetChild(0).gameObject.GetComponent<MeshRenderer>().enabled = true;
		mordant1.transform.GetChild(1).gameObject.GetComponent<MeshRenderer>().enabled = true;
		mordant1.GetComponent<SphereCollider>().enabled = true;

		mordant2.SetActive(true);
		mordant2.transform.parent = shelf2.transform;
		mordant2.transform.GetChild(0).gameObject.GetComponent<MeshRenderer>().enabled = true;
		mordant2.transform.GetChild(1).gameObject.GetComponent<MeshRenderer>().enabled = true;
		mordant2.GetComponent<SphereCollider>().enabled = true;

		paint1.transform.localPosition = new Vector3(0.1f,-0.91f, 0.668f);
		paint1.transform.localEulerAngles = new Vector3(0.0f,-90.0f,0.0f);
		paint2.transform.localPosition = new Vector3(0.1f, -0.91f, 0.006f);
		paint2.transform.localEulerAngles = new Vector3(0.0f, -90.0f, 0.0f);
		mordant1.transform.localPosition = new Vector3(0.14f, -0.687f, -0.685f);
		mordant1.transform.localEulerAngles = new Vector3(0.0f, 0.0f, 0.0f);
		mordant2.transform.localPosition = new Vector3(0.14f, -0.687f, 0.634f);
		mordant2.transform.localEulerAngles = new Vector3(0.0f, 0.0f, 0.0f);

//		DyeText.enabled = false;
//		MordantText.enabled = false;
		DyeText.text = "";
		MordantText.text = "";
	}

	public void undo()
	{

		int prevdyenumber = dyeselected;
		int prevmnumber = mselected;
		int prevstepnumber = freeplaystepnumber;
		startover();


		//mode 2 not on pointer
		//mode 3 on pointer
		if (prevstepnumber == 3)
		{
			Debug.Log("does this work");
			Debug.Log("THIS IS THE OBJECT");
			Debug.Log(thisadded.tag);
			Debug.Log("THIS IS THE OBJECT");
			if (thisadded.tag.Contains("shelf_dye1") )
			{
				Material m_mat3 = paint1.gameObject.GetComponent<Renderer>().material;
				m_mat3.color = Color.blue;
//				DyeText.enabled = true;
				DyeText.text = "Dye Added";

			}
			if (thisadded.tag.Contains("shelf_dye2"))
			{
				Material m_mat3 = paint1.gameObject.GetComponent<Renderer>().material;
				m_mat3.color = Color.red;
//				DyeText.enabled = true;
				DyeText.text = "Dye Added";
			}

			if (thisadded.tag.Contains("shelf_mordant1") )
			{
//				MordantText.enabled = true;
				MordantText.text = "Mordant Added";
			}
			if (thisadded.tag.Contains("shelf_mordant2"))
			{
//				MordantText.enabled = true;
				MordantText.text = "Mordant Added";
			}

			thisadded.SetActive(false);
			mselected = prevmnumber;
			dyeselected = prevdyenumber;
			freeplaystepnumber = prevstepnumber - 1;
		}
	}


	// Update is called once per frame
	void Update () {

	}


	void Start () {
		freeplaystepnumber = 0;
		mode = 0;
		objectselected = 0;
		dyeselected = 0;
		mselected = 0;
		Shelf = GameObject.Find ("Shelf");
		Shelf2 = GameObject.Find ("Shelf2");
		Beaker = GameObject.Find ("Beaker");
		Arrow = GameObject.Find ("Arrow");
		Cylinder = GameObject.Find ("Cylinder");
		Hand = GameObject.Find ("Hand");
		pointerScript = GameObject.Find ("Cylinder").GetComponent<PointerScript> ();
		walkthroughScript = GameObject.Find ("Light").GetComponent<WalkthroughScript> ();
		ExitFreePlayScreen = GameObject.Find ("ExitFreeplayScreen");
		ConfirmExitScreen = GameObject.Find ("ConfirmExitScreen");
		StartScreen = GameObject.Find ("StartScreen");

		ExitFreePlayScreen.SetActive (false);
		ConfirmExitScreen.SetActive (false);
	}


	//	void Start () {
	//		freeplaystepnumber = 0;
	//		mode = 0;
	//		objectselected = 0;
	//
	//		Shelf = GameObject.Find ("Shelf");
	//		Shelf2 = GameObject.Find ("Shelf2");
	//		Beaker = GameObject.Find ("Beaker");
	//		Arrow = GameObject.Find ("Arrow");
	//		pointerScript = GameObject.Find ("Cylinder").GetComponent<PointerScript> ();
	//	}
	//

	public void Steps(int f)
	{
		if (f == 0)
		{
			freeplaystepnumber = 0;
			Debug.Log("pick dye");
			mode = 1;
			instantiateFreePlayBoard ();
			ExitFreePlayScreen.SetActive (true);
		}

		if (f == 1)
		{
			freeplaystepnumber = 1;
			Debug.Log("pour dye");
		}
		if (f == 2)
		{
			freeplaystepnumber = 2;
			Debug.Log("pick mordant");
		}
		if (f == 3)
		{
			freeplaystepnumber = 3;
			Debug.Log("add mordant");
		}
		if (f == 4)
		{
			freeplaystepnumber = 4;
			Debug.Log("process finished");
		}
	}


	void instantiateFreePlayBoard(){
		Shelf.SetActive (true);
		Shelf2.SetActive (true);
		//        Cylinder.SetActive (true);
		Cylinder.SetActive(false);
		Hand.SetActive (true);
		Arrow.SetActive (false);
		Beaker.SetActive (true);
		pointerScript.enabled = false;
	}

	public void stopFreeplayMode(){

		//clearWorkspace
		walkthroughScript.clearWorkspace(walkthroughScript.step1);

		//Close ExitFreePlayScreen
		ExitFreePlayScreen.SetActive(false);

		//Show start screen
		StartScreen.SetActive(true);

		//dont show hand anymore
		Hand.SetActive(false);

		startover();
	}



}
